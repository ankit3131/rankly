
        // document.getElementById('menu-toggle').addEventListener('click', function() {
        //     document.getElementById('mobile-menu').classList.toggle('hidden');
        // });
        // var swiper = new Swiper(".mySwiper", {
        //     loop: true,
        //     spaceBetween: 30,
        //     slidesPerView: 1,
        //     pagination: {
        //       el: ".swiper-pagination",
        //       clickable: true,
        //     },
        //     breakpoints: {
        //       768: { slidesPerView: 2 },  // Medium Screens: 2 Slides
        //       1024: { slidesPerView: 2 }  // Large Screens: 3 Slides
        //     }
        //   });

          // let currentIndex = 0;
          // const slider = document.getElementById("testimonial-slider");
          // const totalSlides = slider.children.length;
          
          // function updateSlide() {
          //     const screenWidth = window.innerWidth;
          //     const slideWidth = screenWidth >= 768 ? slider.clientWidth / 3 : slider.clientWidth;
          //     slider.style.transform = `translateX(-${currentIndex * slideWidth}px)`;
          // }
          
          // function nextSlide() {
          //     currentIndex = (currentIndex + 1) % totalSlides;
          //     updateSlide();
          // }
          
          // function prevSlide() {
          //     currentIndex = (currentIndex - 1 + totalSlides) % totalSlides;
          //     updateSlide();
          // }
          
          // window.addEventListener("resize", updateSlide);
          // updateSlide();
          
          // setInterval(nextSlide, 3000); // Auto-slide every 3 seconds